<?php
	session_start();
	if (isset($_SESSION['userlogin'])) {
		header("");
	}
?>

<?php require_once 'controllers/authController.php'?>


<?php include "./views/header.php"?>

	<div class="container h-100 mt-5 pt-2">
		<div class="d-flex">
			<div class="user-card">
				<div class="d-flex justify-content-center h-25">
					<div class="brand-logo-container">
						<img class="brand-logo" src="../assets/img/favicons/okcl-logo-md.png" alt="logo">
					</div>
				</div>
				
				<div class="justify-content-center form_container">

					<form action="reset-password.php" method="post">
						<h3 class="text-center">Reset Your Password</h3>

						<div class="input-group mb-3 mx-5" style="width: auto;">
							<label for="password">Password</label>
							<input type="password" name="password" id="password" class="form-control form-control-lg">
						</div>

						<div class="input-group mb-3 mx-5" style="width: auto;">
							<label for="password">Confirm Password</label>
							<input type="password" name="passwordconf" id="passwordconf" class="form-control form-control-lg">
						</div>

						<div class="form-group">
							<button class="btn btn-primary btn-block btn-lg" type="submit" name="resetPwdBtn" id="resetPwd">
								Reset Password
							</button>
						</div>

						
					
				<div class="mt-4">
					<div class="d-flex justify-content-center links">
						<p class="text-danger">Don't have an account?&emsp;</p><a class="ml-2" href="registration.php" style="text-decoration: none;">Sign Up</a>
					</div>
					<div class="d-flex justify-content-center">
						<a href="forgot.php" style="text-decoration: none;">Password Forgotten?</a>
					</div>
				</div>
				</form>
			</div>
			
		</div>
	</div>	
</div>

	<script>
		$(function(){
			$('#login').click(function(e){
				var valid = this.form.checkValidity();

				if (valid) {
					var user = $('#username').val();
					var pass = $('#password').val();
				}
				e.preventDefault();

				$.ajax({
					type:'POST',
					url:'jslogin.php',
					data:{username:user, password:pass},
					success:function(data){
						alert(data);
						if ($.trim(data)==="1") {
							setTimeout('window.location.href = "index.php"',2000);
						}
					},
					error:function(data){
						alert('login operation failed');
					}
				});
			});
		});
	</script>



 <!-- FOOTER -->
 
	<?php include "./views/footer.php"?>