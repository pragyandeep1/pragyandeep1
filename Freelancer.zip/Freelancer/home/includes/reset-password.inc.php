<?php
	
	require_once('config.php');
	session_start();
	if (isset($_GET['email']) && isset($_GET['code'])) {
		$email = $_POST['email'];
		$pass = $_POST['password'];

		// username & password combination or email & password combination
		$sql = "SELECT * FROM users WHERE email = ? LIMIT 1";

		$stmt = $db->prepare($sql);
		$result = $stmt->execute([$email]);
		$user = $result=>fetch();

		print_r($user);

		if (password_verify($pass, $user['password'])) {
			// $user = $stmt->fetch(PDO::FETCH_ASSOC);
			// var_dump($user);
			/*if ($stmt->rowCount()>0) {
				$_SESSION['userlogin'] = $user;
				echo "You are successfully logged in";
			}
			else{
				echo "invalid username or password";
			}*/
		}
		else{
			echo "login operation failed";
		}
	}

?>

<?php

	/*if (isset($_POST['reset-password-submit'])) {
		$selector = $_POST["selector"];
		$validator = $_POST["validator"];
		$password = $_POST["pwd"];
		$passwordRepeat = $_POST["pwd-repeat"];

		if (empty($password)||empty($passwordRepeat)) {
			header("location: create-new-password.php?newpwd=empty");
			exit();
		}
		elseif($password != $passwordRepeat){
			header("location: create-new-password.php?newpwd=pwdnotmatch");
			exit();
		}

		$currentDate = date("U");
		require '../config.php';

		$sql = "SELECT * FROM pwdreset WHERE pwdResetSelector =? AND pwdResetExpires >= ?";
		$stmt = $db->prepare($sql);

		if (!mysql_stmt_prepare($stmt,$sql)) {
			echo "There is an error.";
			exit();
		}
		else{
			mysqli_stmt_bind_param($stmt, "s", $selector, $currentDate);
			mysqli_stmt_execute($stmt);

			$result = mysqli_stmt_get_result($stmt);
			if (!$row = mysqli_fetch_assoc($result)) {
				echo "Please submit your reset request again.";
				exit();
			}
			else{

				$tokenBin = hex2bin($validator);
				$tokenCheck = password_verify($tokenBin, $row["pwdResetToken"]);

				if ($tokenCheck === false) {
					echo "Please submit your reset request again.";
					exit();
				}
				elseif ($tokenCheck === true) {
					$tokenEmail = $row['pwdResetEmail'];
					$sql = "SELECT * FROM users WHERE emailUsers=?;";

					$stmt = mysqli_stmt_init($db);

					if (!mysql_stmt_prepare($stmt,$sql)) {
						echo "There is an error.";
						exit();
					}
					else{
						mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);
						if (!$row = mysqli_fetch_assoc($result)) {
							echo "There is an error.";
							exit();
						}
						else{
							$sql = "UPDATE users SET pwdUsers=? WHERE emailUsers=?";
							$stmt = mysqli_stmt_init($db);

							if (!mysql_stmt_prepare($stmt,$sql)) {
								echo "There is an error.";
								exit();
							}
							else{
								$newPwdHash = password_hash($password, PASSWORD_DEFAULT);
								mysqli_stmt_bind_param($stmt, "ss", $newPwdHash, $tokenEmail);
								mysqli_stmt_execute($stmt);

								$sql = "DELETE FROM pwdreset WHERE pwdResetEmail=?;";

								$stmt = mysqli_stmt_init($db);

								if (!mysql_stmt_prepare($stmt,$sql)) {
									echo "There is an error.";
									exit();
								}
								else{
									mysqli_stmt_bind_param($stmt, "s", $userEmail);
									mysqli_stmt_execute($stmt);
									header("location: registration.php?newpwd=passwordupdated");
								}
							}
						}
					}
				}
			}
		}
	}
	else{
		header("location: index.php");
	}*/
?>