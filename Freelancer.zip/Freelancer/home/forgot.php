<?php require_once 'controllers/authController.php'?>
<?php require "./views/header.php"?>
	<div class="container h-100 mt-5 pt-2">
		<div class="user-card">
				<form action="forgot.php" method="post">
					<h3>Recover your password</h3>

					<p class="mx-2">Enter your registered email address in order to recover your password.</p>

					<?php
					 /*if (count($e)>0){
					 	foreach ($e as $error){
					 		echo $error;
					 	}
					}
*/					?>

					<div class="form-group">
						<input class="form-control form-control-lg w-75 mx-4" type="email" name="email" placeholder="Enter your email address...">
					</div>

					<div class="form-group">
						<button class="btn btn-primary btn-block btn-lg mt-3 mx-5 w-50" name="forgot-password" type="submit">
							Recover
						</button>
					</div>
				</form>

				<?php
					if (isset($_GET['reset'])) {
						if ($_GET['reset'] == 'success') {
							echo "<p>Check your email!</p>";
						}
					}
				?>
		</div>
	</div>

<?php require "./views/footer.php"?>