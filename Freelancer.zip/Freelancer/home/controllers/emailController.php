<?php
	session_start();
	require_once('config.php');

	// create mailer using transport
	$mailer = new Swift_Mailer($transport);

	function sendVerificationEmail($userEmail, $token){
		global $mailer;
		
		// create a message
		$msg = (new Swift_Message('Verify email address: '))
		->setFrom(EMAIL)
		->setTo($userEmail)
		->setBody($body, 'text/html');
	}

	// send message
	$result = $mailer -> send($msg);

	function sendPasswordResetLink($userEmail, $token){
		$body = "<?php require 'header.php'?>
	<div class="wrapper">
		<p>Click on the link below to reset your password.</p>
		<a href='http://localhost/Freelancer/home/index.php?password-token=".token."'>
			Reset your password.</a>
	</div>

<?php require 'footer.php'?>";
	}

?>