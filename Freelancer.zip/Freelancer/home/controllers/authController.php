<?php
	
	require_once('config.php');
	session_start();
	// verify user by token
	if (isset($_POST['login'])) {
		$email = $_POST['email'];
		$pass = $_POST['password'];

		// Retrieve info from database
		$sql = "SELECT * FROM users WHERE email = ? LIMIT 1";

		$stmt = $db->prepare($sql);
		$result = $stmt->execute([$email]);
		// $user = $result=>fetch();

		// compare input with database
		print_r($user);

		if (password_verify($pass, $user['password'])) {
			header('location:index.php');
		}
	}


	/*function verifyUser($token){
		global $db;
		$sql = "SELECT * FROM users WHERE token = '$token' LIMIT 1";
		$result = mysqli_query($db, $sql);

		if (mysqli_num_rows($result)>0) {
			$user = mysqli_fetch_assoc($result);
			$update_query = "UPDATE users SET verified=1 WHERE token = '$token'";
			if (mysqli_query($db, $update_query)) {
				// log user in
				$_SESSION['id'] = $user['id'];
				$_SESSION['username'] = $user['username'];
				$_SESSION['email'] = $user['email'];
				$_SESSION['verified'] = 1;

				// set flash message
				$_SESSION['message'] = 'Your email address has been successfully verified.';
				$_SESSION['alert-class'] = $user['alert-success'];
				header('location: index.php');
				exit(0);
			}
			else{
				echo "user not found.";
			}
		}
	}

	// if user clicks on forgotten password button
	if (isset($_POST['forgot'])) {
		$email = $_POST['email'];

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$errors['email'] = 'Invalid email address';
		}

		if(empty($email)){
			$errors['email'] = 'Email is required.';
		}

		if (count($errors)==0) {
			$sql = 'SELECT * FROM users WHERE email = "$email" LIMIT 1';
			$result = mysqli_query($db, $sql);
			$user = mysqli_fetch_assoc($result);
			$token = $user['token'];
			sendPasswordResetLink($email, $token);
			header('location: password-message.php');
			exit(0);
		}
	}

	// if user clicks on reset paswword button
	if (isset($_POST['resetPwdBtn'])) {
		$pwd = $_POST['password'];
		$pwdconf = $_POST['passwordconf'];

		if (empty($pwd)||empty($pwdconf)) {
			$errors['password'] = "password required";
		}

		if ($pwd != $pwdconf) {
			$errors['password'] = "The passwords don't match.";
		}

		$pwd = pwd_hash($pwd, PASSWORD_DEFAULT);
		$email = $_SESSION['email'];

		if (count($errors)==0) {
			$sql = "UPDATE users SET password = '' WHERE email='$email'";
			$result = mysqli_query($db, $sql);
			if ($result) {
				header('location: login.php');
				exit(0);
			}
		}
	}


	function resetPassword($token){
		global $db;
		$sql = "SELECT * FROM users WHERE token = '$token' LIMIT 1";
		$result = mysqli_query($db, $sql);
		$user = mysqli_fetch_assoc($result);
		$_SESSION['email'] = $user['email'];
		header('location: reset-password.php');
		exit(0);
	}*/

?>