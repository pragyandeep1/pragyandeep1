<?php
	session_start();
	if (!isset($_SESSION['userlogin'])) {
		header("");
	}
?>

<?php include "./views/header.php"?>

	<div class="container h-100 mt-5 pt-2">
		<div class="d-flex">
			<div class="user-card mx-auto">
				<div class="d-flex justify-content-center h-25">
					<div class="brand-logo-container">
						<img class="brand-logo" src="../img/favicons/okcl-logo-md.png" alt="logo">
					</div>
				</div>
				
				<div class="justify-content-center form_container">

					<form action="jslogin.php" method="post">
						<div class="input-group mb-3 mx-5" style="width: auto;">
							<div class="input-group-append">
								<span class="input-group-text">
									<i class="fa fa-user"></i>
								</span>
							</div>
							<input type="text" name="username" id="username" class="form-control input-user" required>
						</div>
						<div class="input-group mb-3 mx-5" style="width: auto;">
							<div class="input-group-append">
								<span class="input-group-text">
									<i class="fa fa-lock"></i>
								</span>
							</div>
							<input type="password" name="password" id="password" class="form-control input-pass" required>
							<!-- <button class="visibility-toggle">show</button> -->
							<!-- <span class="material-icons-outlined">visibility</span> -->
						</div>
						<div class="form-group">
							<div class="custom-control custom-checkbox mx-5">
								<input type="checkbox" name="remember_me" class="custom-control-input" id="customControlInline" required>
								<label class="custom-control-label" required>Remember Me</label>
							</div>
						</div>

						<div class="d-flex justify-content-center mt-3 login-container">
							<button class="btn login-btn text-md-center" type="button" id="login" name="login" onclick="login_click(this)">Login</button>
						</div>
					
				<div class="mt-4">
					<div class="d-flex justify-content-center links">
						<p class="text-danger">Don't have an account?&emsp;</p><a class="ml-2" href="registration.php" style="text-decoration: none;">Sign Up</a>
					</div>
					<div class="d-flex justify-content-center">
						<a href="forgot.php" style="text-decoration: none;">Password Forgotten?</a>
					</div>
				</div>
				</form>
			</div>
			
		</div>
	</div>	
</div>

<script type="text/javascript" src="../js/script_signin.js"></script>

 <!-- FOOTER -->
<?php include "./views/footer.php"?>