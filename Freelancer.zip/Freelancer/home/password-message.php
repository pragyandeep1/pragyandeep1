<?php require_once 'controllers/authController.php'?>
<?php include "./views/header.php"?>

<div class="container h-100 mt-5 pt-2">
	<div class="user-card">
		<p>An email has been sent to your registered email id with instructions to reset your password</p>
		
	</div>
</div>

<?php include "./views/footer.php"?>