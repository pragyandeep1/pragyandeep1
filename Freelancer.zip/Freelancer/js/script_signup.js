	function validate(){

		var form = document.getElementById("signup_form");
		var email = document.getElementById("email");
		var password = document.getElementById("password");
		var password_confirm = document.getElementById("confPassword");
		/*var regx = /^[6-9][0-9]\d{9}$/;*/

		//email validation
		if (email.value == "") {
			email.style.border = "1px solid red";
			email.focus();
			return false;
		}

		/*if(!preg_match('/^([6-9]\d{9})$/', $contact)){
			return = false;
			alert("Please enter a valid mobile number!");
		}
*/
		/*if (regx.test(contact)) {
			document.getElementById("validity").innerHTML = "Valid";
			document.getElementById("validity").style.visibility = "visible";
			document.getElementById("validity").style.color = "green";
		}
		else{
			document.getElementById("validity").innerHTML = "InValid";
			document.getElementById("validity").style.visibility = "visible";
			document.getElementById("validity").style.color = "red";
		}*/

		//password validation
		if (password.value == "") {
			password.style.border = "1px solid red";
			alert ("password required");
			password.focus();
			return false;
		}

		//check whether two passwords match
		if (password.value != password_confirm.value) {
			password.style.border = "1px solid red";
			password_confirm.style.border = "1px solid red";
			alert ("The passwords don't match! Try again.");
			return false;
		}

		form.submit();
	}

	function delayRedirect(){
		document.getElementById('delayMag').innerHTML = "Please wait you'll be redirected after <span id='countDown'>3</span> seconds";
		
	}