// login authorization script
function login_click(e){				
	var valid = e.form.checkValidity();
	if (valid) {
		var user = $('#username').val();
		var pass = $('#password').val();
	}
	// e.preventDefault();
	$.ajax({
		type:'POST',
		url:'jslogin.php',
		data:{username:user, password:pass},
		success:function(data){
			alert(data);
			if ($.trim(data)==="1") {
				setTimeout('window.location.href = "index.php"',2000);
			}
		},
		error:function(data){
			alert('login operation failed');
		}
	});	
}