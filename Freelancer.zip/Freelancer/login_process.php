<?php
 try {
   $handler = new PDO('mysql:host=127.0.0.1;dbname=loginsytem', 'root', '');
   $handler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 } catch(PDOException $e){
   echo $e->getName();
   die();
 }

 session_start();

 $query = $handler->query('SELECT * FROM users');

 if (isset($_POST['submit'])) {

   incude_'dbh.inc.php';

   $uid = PDO::quote($conn, $_POST['uid']);
   $pwd = PDO::quote($conn, $_POST['pwd']);

   //Error Handlers
   //Check if inputs are empty

   if (empty($uid)) || empty($pwd)) {
     header("location: ../index.php?login=empty");
     exit();
   }
 }   else {
     $sql = "SELECT * FROM users WHERE user_uid='$uid'";
     $result = mysqli_query($conn, $sql);
     $resultCheck = mysqli_num_rows($result);
     if ($resultCheck < 1) {
       header("location: ../index.php?login=error");
       exit();
     } else {
       if ($row = mysqli_fetch_assoc($result)) {
         //de-hashing the password
         $hashedPwdCheck = password_verify($pwd, $row['user_pdw']);
         if ($hashedPwdCheck == false) {
           header("location: ../index.php?login=error");
           exit();

         } elseif ($hashedPwdCheck == true) {
           //Log in the user here
           $_SESSION['u_id'] = $row['user_id'];
           $_SESSION['u_uid'] = $row['user_uid'];
           header("location: ../index.php?login=success");
           exit();
         }
       }
     }
   }

   else {
   header("location: ../index.php?login=error");
   exit();
 }


 ?>